# Flappy-birds-using-pygame

I used Python and the Pygame package to re create the game Flappy bird.
I added comments throughout which hopefully makes it easier to understand for a beginner and I also refrained from using object oriented programming for the same reason.

# Video Tutorial
I made a beginner friendly tutorial on my YouTube channel: https://www.youtube.com/watch?v=rO_UU_Uu8EQ
